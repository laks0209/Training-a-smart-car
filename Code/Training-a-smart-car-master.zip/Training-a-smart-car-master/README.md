# Training-a-smart-car
Developed a program to train a cab to follow US traffic rules. 
Approach: Performed parametric study to tune and improve Q-learning efficiency. 
Tool: Python. 
Result: Efficiency improvement upto 10%.
